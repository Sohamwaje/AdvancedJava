package com.util;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.service.ServiceRegistry;

import com.bean.Student;

public class DbConnection {
	private static SessionFactory sf ;
	
	public static SessionFactory getSf() {
		
		if(sf== null) {
			
			try {
				Configuration config = new Configuration();
				
				Properties set = new Properties();
				
				set.put(Environment.DRIVER,"com.mysql.cj.jdbc.Driver");
				set.put(Environment.URL,"jdbc:mysql://localhost:3306/hibernate");
				set.put(Environment.USER,"root");
				set.put(Environment.PASS,"Amit2000");
				
				//skipped to understand
			    set.put(Environment.DIALECT, "org.hibernate.dialect.MySQL5Dialect");

			    set.put(Environment.SHOW_SQL, "true");

			    set.put(Environment.CURRENT_SESSION_CONTEXT_CLASS, "thread");

			    set.put(Environment.HBM2DDL_AUTO, "update");

			    config.setProperties(set);
			    
			    config.addAnnotatedClass(Student.class);
			    
			    ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(config.getProperties()).build();
			    System.out.println("Hibernate Java Config serviceRegistry created");
			    sf =config.buildSessionFactory(serviceRegistry);
			    return sf;
				
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		return sf;
		
	}
}
