package com.crud;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.bean.Student;
import com.util.DbConnection;

public class Delete {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       SessionFactory sf = DbConnection.getSf();
		
		Session session = sf.openSession();
		
		session.beginTransaction();
		
		Student stud = (Student) session.get(Student.class,2);
		
		session.delete(stud);
		System.out.println("are data delete bhi ho gya");
		
		session.getTransaction().commit();
		session.close();
		sf.close();
		
	}

}
