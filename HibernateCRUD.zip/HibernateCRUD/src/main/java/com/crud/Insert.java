package com.crud;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.bean.Student;
import com.util.DbConnection;

public class Insert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student stud = new Student();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Name");
		String name = sc.nextLine();
		System.out.println("Enter Branch");
		String branch= sc.nextLine();
		System.out.println("Enter Marks");
		int marks = sc.nextInt();
		
		stud.setName(name);
		stud.setCourse(branch);
		stud.setMarks(marks);
		
		SessionFactory sf = DbConnection.getSf();
		
		Session session = sf.openSession();
		
		session.beginTransaction();
		session.save(stud);
		
		System.out.println("mahadev ki kripa se data bhi aa gya");
		session.getTransaction().commit();
		session.close();
		sf.close();
		
	}

}
