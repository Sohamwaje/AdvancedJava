package com.crud;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.bean.Student;
import com.util.DbConnection;

public class UpdateData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		SessionFactory sf = DbConnection.getSf();
		Session session = sf.openSession();
		session.beginTransaction();
		System.out.println("Enter Id to update name");
		int id = sc.nextInt();
		Student stud = (Student) session.get(Student.class, id);
		stud.setName("Sai Jadhav");
		System.out.println("Data updated successfully");
		
		
//		System.out.println("Enter 1 to update name\n Enter 2 to update course \n Enter 3 to update marks ");
//		int a = sc.nextInt();
//		switch (a){
//		case 1:{
//			System.out.println("Enter Id to update name");
//			int id = sc.nextInt();
//			
//			System.out.println("Enter name");
//			String name = sc.nextLine();
//			
//             break;
//		  }
//		
//		case 2:{
//			System.out.println("Enter Id to update course");
//			int id = sc.nextInt();
//			System.out.println("Enter course");
//			String name = sc.nextLine();
//			Student stud = (Student) session.get(Student.class, id);
//			stud.setCourse(name);
//			System.out.println("Data updated successfully");
//			break;
//			
//		  }
//		
//		case 3:{
//			System.out.println("Enter Id to update marks");
//			int id = sc.nextInt();
//			System.out.println("Enter marks");
//			int name = sc.nextInt();
//			Student stud = (Student) session.get(Student.class, id);
//			stud.setMarks(name);
//			System.out.println("Data updated successfully");
//			break;
//		  }
//			
//		}
		
		session.getTransaction().commit();
		session.close();
		sf.close();
		
	}

}
