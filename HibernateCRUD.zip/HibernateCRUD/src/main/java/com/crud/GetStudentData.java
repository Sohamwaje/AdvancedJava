package com.crud;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.bean.Student;
import com.util.DbConnection;

public class GetStudentData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sf = DbConnection.getSf();
		Session session = sf.openSession();
		
		session.beginTransaction();
		
		Query <Student> query = session.createQuery("from Student");
		List <Student> students = query.list();
		for(Student stud:students) {
			System.out.println("Id is     : "+stud.getId());
			System.out.println("Name is   : "+stud.getName());
			System.out.println("Course is : "+stud.getCourse());
			System.out.println("Marks is  : "+stud.getMarks());
		}
		
		session.getTransaction().commit();
		session.close();
		sf.close();
		
	}

}
